<script setup>
const model = ref(0);
const colors = ref([
  "primary",
  "secondary",
  "yellow darken-2",
  "red",
  "orange",
]);
</script>

<template>
  <v-card>
    <v-carousel v-model="model">
      <v-carousel-item v-for="(color, i) in colors" :key="i">
        <v-sheet :color="color" height="100%" tile>
          <div class="d-flex fill-height justify-center align-center">
            <div class="text-h2">Slide {{ i + 1 }}</div>
          </div>
        </v-sheet>
      </v-carousel-item>
    </v-carousel>
  </v-card>
</template>
