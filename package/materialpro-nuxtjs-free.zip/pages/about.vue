<template>
  <div>This is about page <NuxtLink to="/">Home page</NuxtLink></div>
</template>

<script setup>
definePageMeta({
  layout: "blank",
});
</script>
