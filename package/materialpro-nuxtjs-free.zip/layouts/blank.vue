<script setup lang="ts">
useMeta({
  title: "MaterialPro Free NuxtJs 3 Dashboard",
});
</script>
<template>
  <v-app>
    <slot />
  </v-app>
</template>
